<?php
function singleProductData($post)
{
  $product = wc_get_product($post->ID);
  $product_data =  get_san_pham($product);
  $product_data['nonce'] = wp_create_nonce("wp_rest");
  $cat = get_the_terms($post->ID, 'product_cat')[0];
  $results = wc_get_products(["category" => [$cat->slug]]);
  $cart_products = [];
  // $related_product_ids = spero_related_products($product->get_id());

  // foreach ($related_product_ids as $related_product_id) {
  //   array_push($related_products,   get_san_pham(wc_get_product($related_product_id)));
  // }

  // $product_data['data']['related_products'] = $related_products;

  foreach ($results as $result) {
    if ($result->get_id() == $post->ID) {
      continue;
    }
    array_push($cart_products,   get_san_pham($result));
  }
  $product_data['data']['cat_products'] = $cart_products;
  return $product_data;
}

function spero_related_products($product_id, $limit = 5, $exclude_ids = array())
{

  $product_id     = absint($product_id);
  $limit          = $limit >= -1 ? $limit : 5;
  $exclude_ids    = array_merge(array(0, $product_id), $exclude_ids);
  $transient_name = 'wc_related_' . $product_id;
  $query_args     = http_build_query(
    array(
      'limit'       => $limit,
      'exclude_ids' => $exclude_ids,
    )
  );

  $transient     = get_transient($transient_name);
  $related_posts = $transient && is_array($transient) && isset($transient[$query_args]) ? $transient[$query_args] : false;

  // We want to query related posts if they are not cached, or we don't have enough.
  if (false === $related_posts || count($related_posts) < $limit) {

    $cats_array = apply_filters('woocommerce_product_related_posts_relate_by_category', true, $product_id) ? apply_filters('woocommerce_get_related_product_cat_terms', wc_get_product_term_ids($product_id, 'product_cat'), $product_id) : array();
    $tags_array = apply_filters('woocommerce_product_related_posts_relate_by_tag', true, $product_id) ? apply_filters('woocommerce_get_related_product_tag_terms', wc_get_product_term_ids($product_id, 'product_tag'), $product_id) : array();

    // Don't bother if none are set, unless woocommerce_product_related_posts_force_display is set to true in which case all products are related.
    if (empty($cats_array) && empty($tags_array) && !apply_filters('woocommerce_product_related_posts_force_display', false, $product_id)) {
      $related_posts = array();
    } else {
      $data_store    = WC_Data_Store::load('product');
      $related_posts = $data_store->get_related_products($cats_array, $tags_array, $exclude_ids, $limit + 10, $product_id);
    }

    if ($transient && is_array($transient)) {
      $transient[$query_args] = $related_posts;
    } else {
      $transient = array($query_args => $related_posts);
    }

    set_transient($transient_name, $transient, DAY_IN_SECONDS);
  }

  $related_posts = apply_filters(
    'woocommerce_related_products',
    $related_posts,
    $product_id,
    array(
      'limit'        => $limit,
      'excluded_ids' => $exclude_ids,
    )
  );

  if (apply_filters('woocommerce_product_related_posts_shuffle', true)) {
    shuffle($related_posts);
  }

  return array_slice($related_posts, 0, $limit);
}


function get_cart()
{

  if (null === WC()->cart && function_exists('wc_load_cart')) {
    wc_load_cart();
  }

  $count = WC()->cart->get_cart_contents_count();
  $cart = array(
    "items" => WC()->cart->get_cart(),
    "total" =>   WC()->cart->cart_contents_total,
    "shipping_total" =>   WC()->cart->shipping_total,
    "checkout_total" =>   WC()->cart->total,
    "discount_total" =>   WC()->cart->discount_total,
    "count" => $count,
    'update_order_review_nonce' => wp_create_nonce('update-order-review'),
    'ajaxUrl' => get_home_url() . '/?wc-ajax=minicart_remove_item',
    'woocommerce-process-checkout-nonce' => wp_create_nonce('woocommerce-process_checkout'),
    "shipping_method_id" => "",
  );

  if (!empty($cart["items"])) {
    foreach ($cart["items"] as $item) {
      $cart["items"][$item["key"]]["data"] =  get_san_pham(wc_get_product($item["product_id"]));
    }
  }
  if ($count) {
    Custom_WC_AJAX::minicart_update_order_review();
    // WC()->cart->calculate_shipping();
    $cart['shipping_method_id'] = array_keys(WC()->shipping()->get_packages()[0]["rates"])[0];
  }
  return rest_ensure_response($cart);
}

function  get_san_pham($product)
{
  try {
    if (empty($product)) return [];
    $product_id = absint($product->get_id());
    // print_r($product);
    $img_urls = [];
    $image_ids = $product->get_gallery_image_ids();

    foreach ($image_ids as $image_id) {
      array_push($img_urls, wc_get_product_attachment_props($image_id));
      // Do something with the image URL
    }

    // $variations = [];
    // foreach ($product->get_variation_attributes() as $attribute_name => $options) {
    //   array_push($variations, array(
    //     'options'   => array("label" => $options),
    //     'attribute' => $attribute_name,
    //     'product'   => $product,
    //   ));
    // }

    $product_data = array(
      'variations' => $product->get_available_variations(),
      'attributes' =>  $product->get_variation_attributes(),
      "weight_unit" => get_option('woocommerce_weight_unit'),
      "slug" => $product->get_slug(),
      'data' => array(
        "product_name" => $product->get_name(),
        "product_id" => $product_id,
        "url" => get_admin_url() . 'admin-ajax.php',
        "short_description" => $product->short_description,
        "description" => $product->description,
        "price" => $product->get_price(),
        "product_image_url" =>  wc_get_product_attachment_props($product->get_image_id()),
        "product_gallery_urls" =>  $img_urls,
        "weight" => $product->weight,
        // "related_products" => $related_products
        "info" => array(
          array("key" => "Độ cao", "value" => get_post_meta($product_id, 'doCao', true)),
          array("key" => "Mùa vụ", "value" => get_post_meta($product_id, 'crop', true)),
          array("key" => "Mức rang", "value" => get_post_meta($product_id, 'level', true)),
          array("key" => "Phương pháp sơ chế", "value" => get_post_meta($product_id, 'method', true)),
        ),
      )
    );

    return $product_data;
  } catch (Exception $e) {
    return [];
  }
}

function custom_get_refreshed_fragments()
{
  ob_start();

  woocommerce_mini_cart();

  $mini_cart = ob_get_clean();
  $quantity = sprintf(_n('%d', '%d', WC()->cart->get_cart_contents_count()), WC()->cart->get_cart_contents_count());
  $cart_data = get_cart()->data;

  $data = array(
    'fragments' => apply_filters(
      'woocommerce_add_to_cart_fragments',
      array(
        'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
        "span#cart-quantity" => '<span class="position-absolute top-50 start-50 cart-quantity" data-quantity="' . $quantity . '" id="cart-quantity">
        ' . $quantity . '
        <span class="visually-hidden">Cart quantity</span>
      </span>'
      )
    ),
    "cart_data" => $cart_data,
    'cart_hash' => WC()->cart->get_cart_hash(),
  );
  wp_send_json($data);
  wp_die();
}

function spero_ajax_add_to_cart()
{
  // check_ajax_referer('update-order-review', 'security');
  $product_id = apply_filters('woocommerce_add_to_cart_product_id', absint($_POST['product_id']));
  $quantity = empty($_POST['quantity']) ? 1 : wc_stock_amount($_POST['quantity']);
  $variation_id = absint($_POST['variation_id']);
  // This is where you extra meta-data goes in
  $cart_item_data = $_POST['meta'];
  $passed_validation = apply_filters('woocommerce_add_to_cart_validation', true, $product_id, $quantity);
  $product_status = get_post_status($product_id);

  // Remember to add $cart_item_data to WC->cart->add_to_cart
  if ($passed_validation && WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $cart_item_data) && 'publish' === $product_status) {

    do_action('woocommerce_ajax_added_to_cart', $product_id);

    if ('yes' === get_option('woocommerce_cart_redirect_after_add')) {
      wc_add_to_cart_message(array($product_id => $quantity), true);
    }

    custom_get_refreshed_fragments();
  } else {

    $data = array(
      'error' => true,
      'product_url' => apply_filters('woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id)
    );

    wp_send_json($data);
  }

  wp_die();
}
