<?php

if (class_exists('WooCommerce')) {
  // code that requires WooCommerce
  class Custom_WC_AJAX extends WC_AJAX
  {

    /**
     * Hook in ajax handlers.
     */
    public static function init()
    {
      add_action('init', array(__CLASS__, 'define_ajax'), 0);
      add_action('template_redirect', array(__CLASS__, 'do_wc_ajax'), 0);
      self::add_ajax_events();
    }

    /**
     * Get WC Ajax Endpoint.
     * @param  string $request Optional
     * @return string
     */
    public static function get_endpoint($request = '')
    {
      return esc_url_raw(add_query_arg('wc-ajax', $request, remove_query_arg(array('remove_item', 'add-to-cart', 'added-to-cart'))));
    }

    /**
     * Set WC AJAX constant and headers.
     */
    public static function define_ajax()
    {
      if (!empty($_GET['wc-ajax'])) {
        if (!defined('DOING_AJAX')) {
          define('DOING_AJAX', true);
        }
        if (!defined('WC_DOING_AJAX')) {
          define('WC_DOING_AJAX', true);
        }
        // Turn off display_errors during AJAX events to prevent malformed JSON
        if (!WP_DEBUG || (WP_DEBUG && !WP_DEBUG_DISPLAY)) {
          @ini_set('display_errors', 0);
        }
        $GLOBALS['wpdb']->hide_errors();
      }
    }

    /**
     * Send headers for WC Ajax Requests
     * @since 2.5.0
     */
    private static function wc_ajax_headers()
    {
      send_origin_headers();
      @header('Content-Type: text/html; charset=' . get_option('blog_charset'));
      @header('X-Robots-Tag: noindex');
      send_nosniff_header();
      nocache_headers();
      status_header(200);
    }

    /**
     * Check for WC Ajax request and fire action.
     */
    public static function do_wc_ajax()
    {
      global $wp_query;
      if (!empty($_GET['wc-ajax'])) {
        $wp_query->set('wc-ajax', sanitize_text_field($_GET['wc-ajax']));
      }
      if ($action = $wp_query->get('wc-ajax')) {
        self::wc_ajax_headers();
        do_action('wc_ajax_' . sanitize_text_field($action));
        die();
      }
    }



    //

    /**
     * default AJAX update order review on checkout.
     */
    public static function default_update_order_review()
    {
      check_ajax_referer('update-order-review', 'security');

      wc_maybe_define_constant('WOOCOMMERCE_CHECKOUT', true);

      if (WC()->cart->is_empty() && !is_customize_preview() && apply_filters('woocommerce_checkout_update_order_review_expired', true)) {
        self::update_order_review_expired();
      }

      do_action('woocommerce_checkout_update_order_review', isset($_POST['post_data']) ? wp_unslash($_POST['post_data']) : ''); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

      $chosen_shipping_methods = WC()->session->get('chosen_shipping_methods');
      $posted_shipping_methods = isset($_POST['shipping_method']) ? wc_clean(wp_unslash($_POST['shipping_method'])) : array();

      if (is_array($posted_shipping_methods)) {
        foreach ($posted_shipping_methods as $i => $value) {
          $chosen_shipping_methods[$i] = $value;
        }
      }

      WC()->session->set('chosen_shipping_methods', $chosen_shipping_methods);
      WC()->session->set('chosen_payment_method', empty($_POST['payment_method']) ? '' : wc_clean(wp_unslash($_POST['payment_method'])));
      WC()->customer->set_props(
        array(
          'billing_country'   => isset($_POST['country']) ? wc_clean(wp_unslash($_POST['country'])) : null,
          'billing_state'     => isset($_POST['state']) ? wc_clean(wp_unslash($_POST['state'])) : null,
          'billing_postcode'  => isset($_POST['postcode']) ? wc_clean(wp_unslash($_POST['postcode'])) : null,
          'billing_city'      => isset($_POST['city']) ? wc_clean(wp_unslash($_POST['city'])) : null,
          'billing_address_1' => isset($_POST['address']) ? wc_clean(wp_unslash($_POST['address'])) : null,
          'billing_address_2' => isset($_POST['address_2']) ? wc_clean(wp_unslash($_POST['address_2'])) : null,
        )
      );

      if (wc_ship_to_billing_address_only()) {
        WC()->customer->set_props(
          array(
            'shipping_country'   => isset($_POST['country']) ? wc_clean(wp_unslash($_POST['country'])) : null,
            'shipping_state'     => isset($_POST['state']) ? wc_clean(wp_unslash($_POST['state'])) : null,
            'shipping_postcode'  => isset($_POST['postcode']) ? wc_clean(wp_unslash($_POST['postcode'])) : null,
            'shipping_city'      => isset($_POST['city']) ? wc_clean(wp_unslash($_POST['city'])) : null,
            'shipping_address_1' => isset($_POST['address']) ? wc_clean(wp_unslash($_POST['address'])) : null,
            'shipping_address_2' => isset($_POST['address_2']) ? wc_clean(wp_unslash($_POST['address_2'])) : null,
          )
        );
      } else {
        WC()->customer->set_props(
          array(
            'shipping_country'   => isset($_POST['s_country']) ? wc_clean(wp_unslash($_POST['s_country'])) : null,
            'shipping_state'     => isset($_POST['s_state']) ? wc_clean(wp_unslash($_POST['s_state'])) : null,
            'shipping_postcode'  => isset($_POST['s_postcode']) ? wc_clean(wp_unslash($_POST['s_postcode'])) : null,
            'shipping_city'      => isset($_POST['s_city']) ? wc_clean(wp_unslash($_POST['s_city'])) : null,
            'shipping_address_1' => isset($_POST['s_address']) ? wc_clean(wp_unslash($_POST['s_address'])) : null,
            'shipping_address_2' => isset($_POST['s_address_2']) ? wc_clean(wp_unslash($_POST['s_address_2'])) : null,
          )
        );
      }

      if (isset($_POST['has_full_address']) && wc_string_to_bool(wc_clean(wp_unslash($_POST['has_full_address'])))) {
        WC()->customer->set_calculated_shipping(true);
      } else {
        WC()->customer->set_calculated_shipping(false);
      }

      WC()->customer->save();

      // Calculate shipping before totals. This will ensure any shipping methods that affect things like taxes are chosen prior to final totals being calculated. Ref: #22708.
      WC()->cart->calculate_shipping();
      WC()->cart->calculate_totals();

      // Get order review fragment.
      ob_start();
      woocommerce_order_review();
      $woocommerce_order_review = ob_get_clean();

      // Get checkout payment fragment.
      ob_start();
      woocommerce_checkout_payment();
      $woocommerce_checkout_payment = ob_get_clean();

      // Get messages if reload checkout is not true.
      $reload_checkout = isset(WC()->session->reload_checkout);
      if (!$reload_checkout) {
        $messages = wc_print_notices(true);
      } else {
        $messages = '';
      }

      unset(WC()->session->refresh_totals, WC()->session->reload_checkout);

      wp_send_json(
        array(
          'result'    => empty($messages) ? 'success' : 'failure',
          'messages'  => $messages,
          'reload'    => $reload_checkout,
          'fragments' => apply_filters(
            'woocommerce_update_order_review_fragments',
            array(
              '.woocommerce-checkout-review-order-table' => $woocommerce_order_review,
              '.woocommerce-checkout-payment' => $woocommerce_checkout_payment,
            )
          ),
        )
      );
    }
    /**
     * AJAX update order review on checkout.
     */
    public static function minicart_update_order_review()
    {
      wc_maybe_define_constant('WOOCOMMERCE_CHECKOUT', true);
      $chosen_shipping_methods = WC()->session->get('chosen_shipping_methods');
      $posted_shipping_methods = isset($_POST['shipping_method']) ? wc_clean(wp_unslash($_POST['shipping_method'])) : array();

      if (is_array($posted_shipping_methods)) {
        foreach ($posted_shipping_methods as $i => $value) {
          $chosen_shipping_methods[$i] = $value;
        }
      }
      WC()->session->set('chosen_shipping_methods', $chosen_shipping_methods);
      WC()->customer->set_props(
        array(
          'billing_country'   => isset($_POST['country']) ? wc_clean(wp_unslash($_POST['country'])) : wc_clean(wp_unslash("VN")),
        )
      );
      if (wc_ship_to_billing_address_only()) {
        WC()->customer->set_props(
          array(
            'shipping_country'   => isset($_POST['country']) ? wc_clean(wp_unslash($_POST['country'])) : wc_clean(wp_unslash("VN")),
          )
        );
      } else {
        WC()->customer->set_props(
          array(
            'shipping_country'   => isset($_POST['s_country']) ? wc_clean(wp_unslash($_POST['s_country'])) : wc_clean(wp_unslash("VN")),
          )
        );
      }
      if (isset($_POST['has_full_address']) && wc_string_to_bool(wc_clean(wp_unslash($_POST['has_full_address'])))) {
        WC()->customer->set_calculated_shipping(true);
      } else {
        WC()->customer->set_calculated_shipping(false);
      }
      WC()->customer->save();
      WC()->cart->calculate_shipping();
      WC()->cart->calculate_totals();

        $available_gateways = WC()->payment_gateways()->get_available_payment_gateways();
        WC()->payment_gateways()->set_current_gateway( $available_gateways );

      $reload_checkout = isset(WC()->session->reload_checkout);
      if (!$reload_checkout) {
        $messages = wc_print_notices(true);
      } else {
        $messages = '';
      }

      unset(WC()->session->refresh_totals, WC()->session->reload_checkout);

      // wp_send_json(
      //   array(
      //     'result'    => empty($messages) ? 'success' : 'failure',
      //     'messages'  => $messages,
      //     'reload'    => $reload_checkout,
      //     'fragments' => apply_filters(
      //       'woocommerce_update_order_review_fragments',
      //       array(
      //         '.woocommerce-checkout-review-order-table' => $woocommerce_order_review,
      //         '.woocommerce-checkout-payment' => $woocommerce_checkout_payment,
      //       )
      //     ),
      //   )
      // );
      return (array(
        'result'    => empty($messages) ? 'success' : 'failure',
        // 'shipping_method_id' => array_keys(WC()->shipping()->get_packages()[0]["rates"])[0],
        'shipping_method_id' => [],
        'woocommerce-process-checkout-nonce' => wp_create_nonce('woocommerce-process_checkout'),
        "available_gateways" => $available_gateways,
      ));
    }

    /**
     * Add custom ajax events here
     */
    public static function add_ajax_events()
    {
      // woocommerce_EVENT => nopriv
      $ajax_events = array(
        'minicart_remove_item' => true,
        'minicart_update_order_review' => true,
      );
      foreach ($ajax_events as $ajax_event => $nopriv) {
        add_action('wp_ajax_woocommerce_' . $ajax_event, array(__CLASS__, $ajax_event));
        if ($nopriv) {
          add_action('wp_ajax_nopriv_woocommerce_' . $ajax_event, array(__CLASS__, $ajax_event));
          // WC AJAX can be used for frontend ajax requests
          add_action('wc_ajax_' . $ajax_event, array(__CLASS__, $ajax_event));
        }
      }
    }

    /**
     * Get a refreshed cart fragment. 
     * 
     * Copied from WC_AJAX but changed how data is returned. 
     * You can add fragments (DOM Objects loaded via AJAX) by adding them
     * through the 'add_to_cart_fragments'. 
     * It's better to do it this way so you don't have to create the DOM via
     * javascript because WooCommerce have a general javascript code that will
     * automatically change the DOM Object for all the fragments loaded
     * through here. I will give more info about this later.
     */
    public static function get_refreshed_fragments_raw()
    {
      // Get mini cart
      ob_start();
      woocommerce_mini_cart();
      $mini_cart = ob_get_clean();
      // Fragments and mini cart are returned
      $data = array(
        'fragments' =>
        apply_filters(
          'woocommerce_add_to_cart_fragments',
          array(
            'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>', "run" => "true"
          )
        ),
        'cart_hash' =>
        apply_filters(
          'woocommerce_add_to_cart_hash',
          WC()->cart->get_cart_for_session() ? md5(json_encode(WC()->cart->get_cart_for_session())) : '',
          WC()->cart->get_cart_for_session()
        )
      );
      /**
       * Used 'return' here instead of 'wp_send_json()';
       */
      return ($data);
    }
    /**
     * Removes item from the cart then returns a new fragment
     */
    public static function minicart_remove_item()
    {
      $cart_key = $_POST['cart_key'];
      if (!empty($cart_key)) {
        if (WC()->cart->remove_cart_item($cart_key)) {
          // Response
          // $new_fragments = self::get_refreshed_fragments_raw();
          wp_send_json(array("CART_DATA" => get_cart()->data));
          die(json_encode($new_fragments));
        }
      }
      die("error!!!!");
    }
  }

  $custom_wc_ajax = new Custom_WC_AJAX();
  $custom_wc_ajax->init();
} else {
  // you don't appear to have WooCommerce activated
}


function custom_wc_cart_totals_shipping_html()
{
  $packages = WC()->shipping()->get_packages();
  $first    = true;

  foreach ($packages as $i => $package) {
    $chosen_method = isset(WC()->session->chosen_shipping_methods[$i]) ? WC()->session->chosen_shipping_methods[$i] : '';
    $product_names = array();

    if (count($packages) > 1) {
      foreach ($package['contents'] as $item_id => $values) {
        $product_names[$item_id] = $values['data']->get_name() . ' &times;' . $values['quantity'];
      }
      $product_names = apply_filters('woocommerce_shipping_package_details_array', $product_names, $package);
    }
    $first = false;
    return json_encode(array(
      'package'                  => $package,
      'available_methods'        => $package['rates'],
      'show_package_details'     => count($packages) > 1,
      'show_shipping_calculator' => is_cart() && apply_filters('woocommerce_shipping_show_shipping_calculator', $first, $i, $package),
      'package_details'          => implode(', ', $product_names),
      /* translators: %d: shipping package number */
      'package_name'             => apply_filters('woocommerce_shipping_package_name', (($i + 1) > 1) ? sprintf(_x('Shipping %d', 'shipping packages', 'woocommerce'), ($i + 1)) : _x('Shipping', 'shipping packages', 'woocommerce'), $i, $package),
      'index'                    => $i,
      'chosen_method'            => $chosen_method,
      'formatted_destination'    => WC()->countries->get_formatted_address($package['destination'], ', '),
      'has_calculated_shipping'  => WC()->customer->has_calculated_shipping(),
    ));
  }
}
