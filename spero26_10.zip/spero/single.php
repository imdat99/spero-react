<?php get_header(); ?>
<div class="ahihi">
  chafo banj
</div>
<?php get_footer() ?>