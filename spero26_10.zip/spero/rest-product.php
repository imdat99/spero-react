<?php
add_action('rest_api_init', 'route_cart');
function route_cart()
{
  register_rest_route("vendor/v", '/cart', [
    'methods' => 'GET',
    'callback' => 'get_cart',
    'permission_callback' => '__return_true'
  ]);
  register_rest_route("vendor/v", '/products', [
    'methods' => 'GET',
    'callback' => 'getDataProducts',
    'permission_callback' => '__return_true'
  ]);
  register_rest_route("vendor/v", '/product-detail', [
    'methods' => 'GET',
    'callback' => 'getProductDetail',
    'permission_callback' => '__return_true'
  ]);
  register_rest_route("vendor/v", '/page_endpoint', [
    'methods' => 'GET',
    'callback' => 'get_page_url',
    'permission_callback' => '__return_true'
  ]);
  // register_rest_route("vendor", '/checkout-info', [
  //   'methods' => 'GET',
  //   'callback' => 'spero_checkout_info',
  //   'permission_callback' => '__return_true'
  // ]);
  register_rest_route("vendor/v", '/checkout', [
    'methods' => 'GET',
    'callback' =>
    function () {
      global $wp;
      return rest_ensure_response(
        array(
          'ajax_url'                  => WC()->ajax_url(),
          'wc_ajax_url'               => WC_AJAX::get_endpoint('%%endpoint%%'),
          'update_order_review_nonce' => wp_create_nonce('update-order-review'),
          'apply_coupon_nonce'        => wp_create_nonce('apply-coupon'),
          'remove_coupon_nonce'       => wp_create_nonce('remove-coupon'),
          'option_guest_checkout'     => get_option('woocommerce_enable_guest_checkout'),
          'checkout_url'              => WC_AJAX::get_endpoint('checkout'),
          'is_checkout'               => is_checkout() && empty($wp->query_vars['order-pay']) && !isset($wp->query_vars['order-received']) ? 1 : 0,
          'i18n_checkout_error'       => esc_attr__('Error processing checkout. Please try again.', 'woocommerce'),
          'woocommerce-process-checkout-nonce' => wp_create_nonce('woocommerce-process_checkout'),
        ),
      );
    },
    'permission_callback' => '__return_true'
  ]);
}

function getProductDetail($request)
{
  $slug = $request["slug"];
  $product_obj = get_page_by_path($slug, OBJECT, 'product');
  return rest_ensure_response(singleProductData($product_obj));
}

function get_page_url()
{
  ob_start();
  if (null === WC()->cart && function_exists('wc_load_cart')) {
    wc_load_cart();
    woocommerce_checkout_payment();
  }
  $woocommerce_checkout_payment = ob_get_clean();
  $page_url = array(
    'homeUrl' => get_home_url(),
    'checkoutUrl' => wc_get_checkout_url(),
    'ajaxUrl' => get_home_url() . "/?wc-ajax=%endpoint%",
    'ajaxEndpoint' => array('remove_item' => 'minicart_remove_item'),
    "ahihi" => $woocommerce_checkout_payment,
  );
  return rest_ensure_response($page_url);
}

function getDataProducts()
{
  $taxonomy     = 'product_cat';
  $orderby      = 'name';
  $show_count   = 1;      // 1 for yes, 0 for no
  $pad_counts   = 1;      // 1 for yes, 0 for no
  $hierarchical = 1;      // 1 for yes, 0 for no  
  $title        = '';
  $empty        = 0;

  $args = array(
    'taxonomy'     => $taxonomy,
    'orderby'      => $orderby,
    'show_count'   => $show_count,
    'pad_counts'   => $pad_counts,
    'hierarchical' => $hierarchical,
    'title_li'     => $title,
    'hide_empty'   => $empty
  );
  $all_categories = get_categories($args);

  $cats_data = [];
  // array_push($cart_products,   get_san_pham($result));
  try {
    foreach ($all_categories as $cat) {
      if ($cat->category_parent == 0 && $cat->count > 0) {
        $category_data = array(
          "id" => $cat->term_id,
          "url" => get_term_link($cat->slug, 'product_cat'),
          "name" => $cat->name,
          "description" =>  $cat->description,
          "products" => [],
        );
        $results = wc_get_products(["category" => [$cat->slug]]);
        foreach ($results as $product) {
          array_push($category_data['products'],   get_san_pham($product));
        }
        array_push($cats_data, $category_data);
      }
    }
    return rest_ensure_response($cats_data);
  } catch (Exception $e) {
    wp_send_json_error($e->getMessage());
  }
}

