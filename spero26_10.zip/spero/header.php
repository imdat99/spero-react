<!DOCTYPE html>

<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- vite -->
  <script type="module">
    import {
      injectIntoGlobalHook
    } from "http://127.0.0.1:5173/@react-refresh";
    injectIntoGlobalHook(window);
    window.$RefreshReg$ = () => {};
    window.$RefreshSig$ = () => (type) => type;
  </script>
  <script type="module" src="http://127.0.0.1:5173/@vite/client"></script>
  <!-- end vite -->
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  <?php
  wp_body_open();
  if (is_page('home')) {
    get_template_part('templates/header', 'home', null);
  } else {
    get_template_part('templates/header', 'page', null);
  } ?>
  <noscript>
    <p class="text-center text-danger m-3">Please turn on javascript to view this page correctly</p>
  </noscript>
  <main id="spero-app"></main>
  <script type="module" src="http://127.0.0.1:5173/src/main.tsx"></script>