<?php

include_once("custom-woocommerce.php");
include_once("help-functions.php");
include_once("rest-product.php");
include_once("knowledgeAboutCoffee.php");

function spero_file()
{

  wp_register_style('Font_Awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css');
  wp_enqueue_style('Font_Awesome');
  wp_register_style('Bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css');
  wp_enqueue_style('Bootstrap');
  wp_register_script('Bootstrap_jQuery', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js', null, null, true);
  wp_enqueue_script('Bootstrap_jQuery');
  wp_enqueue_script('page_jquery', 'https://code.jquery.com/jquery-3.7.1.min.js', null, '1.0', true);
  // wp_register_style('spero_main_style', get_stylesheet_uri());
  // wp_enqueue_style('spero_main_style');

  global $post;
  $post_slug = $post->post_name;
  // echo $post_slug;
  switch ($post_slug) {
    case "home":
      wp_enqueue_script('home_js', get_stylesheet_directory_uri() . '/js/home.js', null, '1.0', true);
      break;
    case "cau-chuyen-thuong-hieu":
      wp_enqueue_script('story_js', get_stylesheet_directory_uri() . '/js/story-page.js', null, '1.0', true);
      break;
    case "lien-he":
      wp_enqueue_script('contact_js', get_stylesheet_directory_uri() . '/js/contact.js', null, '1.0', true);
      break;
    default:
      echo "";
  }
  // http://localhost:8080/wp-admin/admin-ajax.php
  // wp_register_style('global_css', get_stylesheet_directory_uri() . '/css/index.css');
  // wp_enqueue_style('global_css', get_template_directory_uri() . '/css/index.css', false, '1.1', 'all');
  wp_enqueue_script('global_js', get_stylesheet_directory_uri() . '/js/test.js', null, '1.0', true);
  wp_localize_script(
    'global_js',
    '__PRELOADED_DATA__',
    array(
      "PRODUCT_DATA" => is_product() ? singleProductData($post) : [],
      "CART_DATA" => get_cart()->data,
      'woocommerce-process-checkout-nonce' => wp_create_nonce('woocommerce-process_checkout'),
      // 'woocommerce-process-checkout-nonce' => wc_get_var($_REQUEST['woocommerce-process-checkout-nonce'], wc_get_var($_REQUEST['_wpnonce'], '')),
    )
  );
}

add_filter("script_loader_tag", "add_module_to_my_script", 10, 3);
function add_module_to_my_script($tag, $handle, $src)
{
  if ("global_js" === $handle) {
    $tag = '<script type="module" src="' . esc_url($src) . '"></script>';
  }

  return $tag;
}

add_action('wp_enqueue_scripts', 'spero_file');

add_theme_support('title-tag');

// support woocommerce
add_theme_support("woocommerce");

function qty_input_field_on_checkout($quantity_html, $cart_item, $cart_item_key)
{
  $_product = $cart_item['data'];

  if ($_product->is_sold_individually()) {
    $product_quantity = sprintf('1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key);
  } else {
    $product_quantity = woocommerce_quantity_input(
      array(
        'input_name'   => "cart[{$cart_item_key}][qty]",
        'input_value'  => $cart_item['quantity'],
        'max_value'    => $_product->get_max_purchase_quantity(),
        'min_value'    => '0',
        'product_name' => $_product->get_name(),
      ),
      $_product,
      false
    );
  }

  return $product_quantity;
}
/**
 * Add custom scripts
 *
 * @access public
 * @return null
 * @since 1.0.0
 */
function add_scripts()
{

  if (is_checkout()) {
?>
    <script type="text/javascript">
      <?php $admin_url = get_admin_url(); ?>
      jQuery("form.checkout").on("change", "input.qty", function() {

        var data = {
          action: 'zwqcoc_update_order_review',
          security: wc_checkout_params.update_order_review_nonce,
          post_data: jQuery('form.checkout').serialize()
        };

        var req = jQuery.post('<?php echo $admin_url; ?>' + 'admin-ajax.php', data);
        console.log("req", req)
        // req.complete(function(response) {
        //   jQuery('body').trigger('update_checkout');
        //   console.log(response)
        //   jQuery('.ahihihihi', 'body').replaceWith('<div class="ahihihihi" style="display: none">' + response + '</div>')
        // })
      });
    </script>
  <?php
  }
}

/**
 * Fire ajax for custom input field
 *
 * @access public
 * @return null
 * @since 1.0.0
 */
function fire_ajax_to_update_order_reviw()
{

  if (!is_user_logged_in()) {
    add_action('wp_ajax_nopriv_zwqcoc_update_order_review',  'zwqcoc_update_order_review');
    add_action('wp_ajax_nopriv_spero_ajax_add_to_cart', 'spero_ajax_add_to_cart');
    add_action('wp_ajax_nopriv_spero_update_quantity_item', 'spero_update_quantity_item');
    add_action('wp_ajax_nopriv_spero_checkout_data', 'spero_checkout_data');
  } else {
    add_action('wp_ajax_zwqcoc_update_order_review',         'zwqcoc_update_order_review');
    add_action('wp_ajax_spero_checkout_data', 'spero_checkout_data');
    add_action('wp_ajax_spero_update_quantity_item', 'spero_update_quantity_item');
    add_action('wp_ajax_spero_ajax_add_to_cart', 'spero_ajax_add_to_cart');
    add_action('wp_ajax_spero_ajax_add_to_cart', 'spero_ajax_add_to_cart');
  }
}

function spero_checkout_data() {
  if (null === WC()->cart && function_exists('wc_load_cart')) {
    wc_load_cart();
    // print_r($payment_data);
  }
  $available_gateways = Custom_WC_AJAX::minicart_update_order_review()["available_gateways"];
  $curl = curl_init();

  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://raw.githubusercontent.com/kenzouno1/DiaGioiHanhChinhVN/master/data.json",
    CURLOPT_RETURNTRANSFER => true
  ));

  $response = curl_exec($curl);
  curl_close($curl);

  $payment_method = [];
  foreach(array_keys($available_gateways) as $gateways) {
    $tmp = $available_gateways[$gateways];
    array_push($payment_method, array("id" => $tmp->id, "instructions" => $tmp->instructions, "title" => $tmp->title ));
  }

  wp_send_json(array(
    'diaGioiVn'                 => json_decode($response),
    'payment_geateways'        =>  $payment_method
  ));
}

function spero_update_quantity_item()
{
  check_ajax_referer('update-order-review', 'security');
  $count = WC()->cart->get_cart_contents_count();
  if ($count === 0) {
    wp_send_json(
      array(
        'result'    => 'failure',
        'messages'  => "Phiên hoạt đồng của bạn đã hết hạn!",
        'reload'    => true,
        "CART_DATA" => array(
          "items" => [],
          "total" => "0",
          "shipping_total" => "0",
          "checkout_total" => "0",
          "discount_total" => "0",
          "count" => "0",
        ),
      )
    );
  }
  try {

    $values = array();
    parse_str($_POST['update_data'], $values);
    // wc_load_cart();
    WC()->cart->set_quantity($values['item_id'], $values['quantity'], false);
    // woocommerce_cart_totals();
    WC()->cart->calculate_totals();
    // printf(get_cart());
    wp_send_json(array("CART_DATA" => get_cart()->data));
    // WC_Cart::calculate_totals();
    if (empty($values['item_id']) || empty($values['quantity'])) {
      return new WP_Error('invalid_data', 'Invalid data', array('status' => 404));
    } else {
      return new WP_Error('invalid_data', 'Invalid data', array('status' => 404));
    }
  } catch (Exception $e) {
    print_r($e);
  }
  // wp_send_json($values);
}

function zwqcoc_update_order_review()
{

  $values = array();
  parse_str($_POST['post_data'], $values);
  $nonce = $_POST['security'];

  $cart = $values['cart'];
  foreach ($cart as $cart_key => $cart_value) {
    WC()->cart->set_quantity($cart_key, $cart_value['qty'], false);
    // WC()->cart->calculate_totals();
    // woocommerce_cart_totals();
    wp_send_json(array("CART_DATA" => get_cart()->data));
  }
  // exit;
}


add_filter('woocommerce_checkout_cart_item_quantity',  'qty_input_field_on_checkout', 20, 3);
add_action('wp_footer',  'add_scripts');
add_action('init',  'fire_ajax_to_update_order_reviw');

// ajax add to cart


// Display Fields
add_action('woocommerce_product_options_advanced', 'woo_add_custom_advanced_fields');
function woo_add_custom_advanced_fields()
{
  woocommerce_wp_text_input(
    array(
      'id'          => 'doCao',
      'label'       => __('Độ cao', 'woocommerce'),
      'placeholder' => '1500 và 2000m...',
      'desc_tip'    => 'true',
      'description' => __('Nhập giá trị độ cao', 'woocommerce')
    )
  );
  woocommerce_wp_text_input(
    array(
      'id'          => 'crop',
      'label'       => __('Mùa vụ', 'woocommerce'),
      'placeholder' => 'Đông xuân 2023...',
      'desc_tip'    => 'true',
      'description' => __('Nhập giá trị <b>Mùa vụ</b>', 'woocommerce')
    )
  );
  woocommerce_wp_text_input(
    array(
      'id'          => 'level',
      'label'       => __('Mức rang', 'woocommerce'),
      'placeholder' => 'Medium...',
      'desc_tip'    => 'true',
      'description' => __('Nhập giá trị <b>Mức rang</b>', 'woocommerce')
    )
  );
  woocommerce_wp_text_input(
    array(
      'id'          => 'method',
      'label'       => __('Phương pháp sơ chế', 'woocommerce'),
      'placeholder' => 'Honey',
      'desc_tip'    => 'true',
      'description' => __('Nhập <b>Phương pháp sơ chế</b>', 'woocommerce')
    )
  );
}

add_action('woocommerce_process_product_meta', 'woo_add_custom_advanced_fields_save');
function woo_add_custom_advanced_fields_save($post_id)
{
  // Text Field
  if (!empty($_POST['doCao'])) update_post_meta($post_id, 'doCao', esc_attr($_POST['doCao']));
  if (!empty($_POST['crop'])) update_post_meta($post_id, 'crop', esc_attr($_POST['crop']));
  if (!empty($_POST['level'])) update_post_meta($post_id, 'level', esc_attr($_POST['level']));
  if (!empty($_POST['method'])) update_post_meta($post_id, 'method', esc_attr($_POST['method']));
}

add_filter('woocommerce_checkout_fields', 'custom_override_checkout_fields', 99);
function custom_override_checkout_fields($fields)
{
  $fields['billing']['billing_first_name'] = array(
    'label' => __('Họ và tên', 'devvn'),
    'placeholder' => _x('Họ và tên', 'placeholder', 'devvn'),
    'required' => true,
    'class' => array('form-row-first'),
    'clear' => true,
    'priority' => 10
  );
  unset($fields['billing']['billing_last_name']);
  return $fields;
}

function hide_shipping_when_free_is_available($rates, $package)
{
  $new_rates = array();
  foreach ($rates as $rate_id => $rate) {
    // Only modify rates if free_shipping is present.
    if ('free_shipping' === $rate->method_id) {
      $new_rates[$rate_id] = $rate;
      break;
    }
  }

  if (!empty($new_rates)) {
    //Save local pickup if it's present.
    foreach ($rates as $rate_id => $rate) {
      if ('local_pickup' === $rate->method_id) {
        $new_rates[$rate_id] = $rate;
        break;
      }
    }
    return $new_rates;
  }

  return $rates;
}

add_filter('woocommerce_package_rates', 'hide_shipping_when_free_is_available', 10, 2);

add_theme_support('woocommerce', array(
  'thumbnail_image_width' => 200,
));

//Product Tag creation page
function tag_taxonomy_add_new_meta_field()
{
    wp_enqueue_media();
  ?>
  <div class="form-field">
    <label for="term_meta[tg_meta_title]"><?php _e('Tag infomation', 'text_domain'); ?></label>
    <textarea name="term_meta[tg_meta_title]" id="term_meta[tg_meta_title]"></textarea>
    <p class="description"><?php _e('Tag infomation, <= 160 character', 'text_domain'); ?></p>
  </div>
  <!-- up ảnh -->
  <div class="form-field term-thumbnail-wrap">
			<label><?php esc_html_e( 'Thumbnail', 'woocommerce' ); ?></label>
			<div id="product_tag_thumbnail" style="float: left; margin-right: 10px;"><img src="<?php echo esc_url( wc_placeholder_img_src() ); ?>" width="60px" height="60px" /></div>
			<div style="line-height: 60px;">
				<input type="hidden" id="term_meta_product_tag_thumbnail_id" name="term_meta[product_tag_thumbnail_id]" />
				<button type="button" class="upload_image_button button"><?php esc_html_e( 'Upload/Add image', 'woocommerce' ); ?></button>
				<button type="button" class="remove_image_button button"><?php esc_html_e( 'Remove image', 'woocommerce' ); ?></button>
			</div>
			<script type="text/javascript">

				// Only show the "remove image" button when needed
				if ( ! jQuery( '#term_meta_product_tag_thumbnail_id' ).val() ) {
					jQuery( '.remove_image_button' ).hide();
				}

				// Uploading files
				var file_frame;

				jQuery( document ).on( 'click', '.upload_image_button', function( event ) {

					event.preventDefault();

					// If the media frame already exists, reopen it.
					if ( file_frame ) {
						file_frame.open();
						return;
					}

					// Create the media frame.
					file_frame = wp.media.frames.downloadable_file = wp.media({
						title: '<?php esc_html_e( 'Choose an image', 'woocommerce' ); ?>',
						button: {
							text: '<?php esc_html_e( 'Use image', 'woocommerce' ); ?>'
						},
						multiple: false
					});

					// When an image is selected, run a callback.
					file_frame.on( 'select', function() {
						var attachment           = file_frame.state().get( 'selection' ).first().toJSON();
						var attachment_thumbnail = attachment.sizes.thumbnail || attachment.sizes.full;
						jQuery( '#term_meta_product_tag_thumbnail_id' ).val( attachment.id );
						jQuery( '#product_tag_thumbnail' ).find( 'img' ).attr( 'src', attachment_thumbnail.url );
						jQuery( '.remove_image_button' ).show();
					});

					// Finally, open the modal.
					file_frame.open();
				});

				jQuery( document ).on( 'click', '.remove_image_button', function() {
					jQuery( '#product_tag_thumbnail' ).find( 'img' ).attr( 'src', '<?php echo esc_js( wc_placeholder_img_src() ); ?>' );
					jQuery( '#term_meta_product_tag_thumbnail_id' ).val( '' );
					jQuery( '.remove_image_button' ).hide();
					return false;
				});

				jQuery( document ).ajaxComplete( function( event, request, options ) {
					if ( request && 4 === request.readyState && 200 === request.status
						&& options.data && 0 <= options.data.indexOf( 'action=add-tag' ) ) {

						var res = wpAjax.parseAjaxResponse( request.responseXML, 'ajax-response' );
						if ( ! res || res.errors ) {
							return;
						}
						// Clear Thumbnail fields on submit
						jQuery( '#product_tag_thumbnail' ).find( 'img' ).attr( 'src', '<?php echo esc_js( wc_placeholder_img_src() ); ?>' );
						jQuery( '#term_meta_product_tag_thumbnail_id' ).val( '' );
						jQuery( '.remove_image_button' ).hide();
						// Clear Display type field on submit
						jQuery( '#display_type' ).val( '' );
						return;
					}
				} );

			</script>
			<div class="clear"></div>
		</div>
<?php
}
add_action('product_tag_add_form_fields', 'tag_taxonomy_add_new_meta_field', 10, 2);
//Product tag Edit page

function tag_taxonomy_edit_meta_field($term)
{
  //getting term ID
  $term_id = $term->term_id;
  // retrieve the existing value(s) for this meta field. This returns an array
  $term_meta = get_option("taxonomy_" . $term_id);
  // $thumbnail_id = absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );
  $thumbnail_id = absint( $term_meta["product_tag_thumbnail_id"] );

		if ( $thumbnail_id ) {
			$image = wp_get_attachment_thumb_url( $thumbnail_id );
		} else {
			$image = wc_placeholder_img_src();
		}

    wp_enqueue_media();
?>
  <tr class="form-field">
    <th scope="row" valign="top"><label for="term_meta[tg_meta_title]"><?php _e('Tag infomation', 'text_domain'); ?></label></th>
    <td>
      <textarea name="term_meta[tg_meta_title]" id="term_meta[tg_meta_title]"><?php echo esc_attr($term_meta['tg_meta_title']) ? esc_attr($term_meta['tg_meta_title']) : ''; ?></textarea>
      <p class="description"><?php _e('Text will show in bottom, <= 260 character', 'text_domain'); ?></p>
    </td>
  </tr>

  <!-- anh -->
  <tr class="form-field term-thumbnail-wrap">
			<th scope="row" valign="top"><label><?php esc_html_e( 'Thumbnail', 'woocommerce' ); ?></label></th>
			<td>
				<div id="product_tag_thumbnail" style="float: left; margin-right: 10px;"><img src="<?php echo esc_url( $image ); ?>" width="60px" height="60px" /></div>
				<div style="line-height: 60px;">
					<input type="hidden" id="term_meta_product_tag_thumbnail_id" name="term_meta[product_tag_thumbnail_id]" value="<?php echo esc_attr( $thumbnail_id ); ?>" />
					<button type="button" class="upload_image_button button"><?php esc_html_e( 'Upload/Add image', 'woocommerce' ); ?></button>
					<button type="button" class="remove_image_button button"><?php esc_html_e( 'Remove image', 'woocommerce' ); ?></button>
				</div>
				<script type="text/javascript">

					// Only show the "remove image" button when needed
					if ( '0' === jQuery( '#term_meta_product_tag_thumbnail_id' ).val() ) {
						jQuery( '.remove_image_button' ).hide();
					}

					// Uploading files
					var file_frame;

					jQuery( document ).on( 'click', '.upload_image_button', function( event ) {

						event.preventDefault();

						// If the media frame already exists, reopen it.
						if ( file_frame ) {
							file_frame.open();
							return;
						}

						// Create the media frame.
						file_frame = wp.media.frames.downloadable_file = wp.media({
							title: '<?php esc_html_e( 'Choose an image', 'woocommerce' ); ?>',
							button: {
								text: '<?php esc_html_e( 'Use image', 'woocommerce' ); ?>'
							},
							multiple: false
						});

						// When an image is selected, run a callback.
						file_frame.on( 'select', function() {
							var attachment           = file_frame.state().get( 'selection' ).first().toJSON();
							var attachment_thumbnail = attachment.sizes.thumbnail || attachment.sizes.full;
              console.log("attachment_thumbnail", attachment_thumbnail)
              console.log("attachment", attachment)

							jQuery( '#term_meta_product_tag_thumbnail_id' ).val( attachment.id );
							jQuery( '#product_tag_thumbnail' ).find( 'img' ).attr( 'src', attachment_thumbnail.url );
							jQuery( '.remove_image_button' ).show();
						});

						// Finally, open the modal.
						file_frame.open();
					});

					jQuery( document ).on( 'click', '.remove_image_button', function() {
						jQuery( '#product_tag_thumbnail' ).find( 'img' ).attr( 'src', '<?php echo esc_js( wc_placeholder_img_src() ); ?>' );
						jQuery( '#term_meta_product_tag_thumbnail_id' ).val( '' );
						jQuery( '.remove_image_button' ).hide();
						return false;
					});

				</script>
				<div class="clear"></div>
			</td>
		</tr>

<?php
}

add_action('product_tag_edit_form_fields', 'tag_taxonomy_edit_meta_field', 10, 2);
// Save extra taxonomy fields callback function.
function tag_save_taxonomy_custom_meta($term_id)
{
  if (isset($_POST['term_meta'])) {
    $term_meta = get_option("taxonomy_" . $term_id);
    $tag_keys = array_keys($_POST['term_meta']);
    foreach ($tag_keys as $key) {
      if (isset($_POST['term_meta'][$key])) {
        $term_meta[$key] = $_POST['term_meta'][$key];
      }
    }
    // Save the option array.
    update_option("taxonomy_" . $term_id, $term_meta);
  }
}
add_action('edited_product_tag', 'tag_save_taxonomy_custom_meta', 10, 2);
add_action('create_product_tag', 'tag_save_taxonomy_custom_meta', 10, 2);
