<?php
add_action('init', 'people_init');
add_action('init', 'kien_thuc_cf');
function kien_thuc_cf()
{
  $args = [
    'label'  => esc_html__('Tất cả bài viết về kiến thức cà phê', 'text-domain'),
    'labels' => [
      'menu_name'          => esc_html__('Kiến thức cà phê', 'kien-thuc-ca-phe'),
      'name_admin_bar'     => esc_html__('Kiến thức cà phê', 'kien-thuc-ca-phe'),
      'add_new'            => esc_html__('Thêm bài viết về Kiến thức cà phê', 'kien-thuc-ca-phe'),
      'add_new_item'       => esc_html__('Thêm bài viết mới về Kiến thức cà phê', 'kien-thuc-ca-phe'),
      'new_item'           => esc_html__('Bài viết mới', 'kien-thuc-ca-phe'),
      'edit_item'          => esc_html__('Chỉnh sửa', 'kien-thuc-ca-phe'),
      'view_item'          => esc_html__('Xem bài viết Kiến thức cà phê', 'kien-thuc-ca-phe'),
      'update_item'        => esc_html__('Cập nhật bài viết', 'kien-thuc-ca-phe'),
      'all_items'          => esc_html__('Tất cả bài viết về kiến thức cà phê', 'kien-thuc-ca-phe'),
      'search_items'       => esc_html__('Tìm kiếm bài viết về kiến thức cà phê', 'kien-thuc-ca-phe'),
      'parent_item_colon'  => esc_html__('Parent Kiến thức cà phê', 'kien-thuc-ca-phe'),
      'not_found'          => esc_html__('Không tìm thấy bài viết nào!', 'kien-thuc-ca-phe'),
      'not_found_in_trash' => esc_html__('Không có bài viết nào trong thùng rác', 'kien-thuc-ca-phe'),
      'name'               => esc_html__('Tất cả bài viết về kiến thức cà phê', 'kien-thuc-ca-phe'),
      'singular_name'      => esc_html__('Kiến thức cà phê', 'kien-thuc-ca-phe'),
    ],
    'public'              => true,
    'exclude_from_search' => false,
    'publicly_queryable'  => true,
    'show_ui'             => true,
    'show_in_nav_menus'   => true,
    'show_in_admin_bar'   => true,
    "show_in_menu"        => true,
    'show_in_rest'        => true,
    'capability_type'     => 'post',
    'hierarchical'        => true,
    'has_archive'         => true,
    'query_var'           => true,
    'can_export'          => true,
    'rewrite_no_front'    => true,
    'menu_position'       => 5,
    'rest_base'           => 'kien-thuc-cf',
    'menu_icon'           => 'dashicons-welcome-write-blog',
    'supports' => [
      'title',
      'editor',
      'author',
      'thumbnail',
      'trackbacks',
      'custom-fields',
      'comments',
      'revisions',
      'page-attributes',
    ],
    // 'taxonomies' => ['kien_thuc','tag',],
    'rewrite' => true
  ];

  register_post_type('kien-thuc-ca-phe', $args);
}
function people_init()
{
  // create a new taxonomy
  register_taxonomy(
    'kien_thuc',
    'kien-thuc-ca-phe',
    array(
      'label' => __('Chuyên mục'),
      'rewrite' => array('slug' => 'kien-thuc-ca-phe'),
      'hierarchical' => true
    )
  );
}
