// const { variations, data } = window.__SPERO__PRODUCT_DATA_;

// let formData = new FormData();
// formData.append("quantity", "10");
// formData.append("product_id", data.product_id);
// formData.append("add-to-cart", data.product_id);
// formData.append("variation_id", variations[0].variation_id);

// fetch(data.permalink, {
//   method: "POST",
//   credentials: "include",
//   body: formData,
//   //other options
// }).then((response) =>
//   response.text().then((res) => {
//     const quantity_count = /data-quantity="(.*?)"/.exec(res)[1];
//     $("#cart-quantity").text(quantity_count);
//   })
// );
