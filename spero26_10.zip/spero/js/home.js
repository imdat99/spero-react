window.onscroll = function () {
  scrollFunction();
};

function scrollFunction() {
  const isShow = $('[data-bs-toggle="dropdown"]').hasClass("show");
  if (
    document.body.scrollTop > 120 ||
    document.documentElement.scrollTop > 120
  ) {
    document.getElementById("home-header").classList.add("header-color");
  } else {
    if (!isShow) {
      document.getElementById("home-header").classList.remove("header-color");
    }
  }
}

$(document).ready(function () {
  const homeHeader = $("#home-header");
  $(document).click(() => {
    const isShow = $('[data-bs-toggle="dropdown"]').hasClass("show");
    const isScroll =
      document.body.scrollTop > 120 || document.documentElement.scrollTop > 120;
    if (!isScroll) {
      if (isShow) {
        homeHeader.addClass("header-color");
      } else {
        homeHeader.removeClass("header-color");
      }
    }
  });
});
