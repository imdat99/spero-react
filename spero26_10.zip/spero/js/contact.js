$(document).ready(function () {
  window.addEventListener("hashchange", function () {
    location.reload();
  });
  const hash = window.location.hash;
  const defaultHash = ["#lien-he", "#trai-nghiem"];
  if (!hash || !defaultHash.includes(hash)) {
    window.location.hash = defaultHash[0];
  }
  $(hash).addClass("show");
});
