const { variations, data } = window.__SPERO__PRODUCT_DATA_;

let formData = new FormData();
formData.append("quantity", "10");
formData.append("action", "spero_ajax_add_to_cart");
formData.append("product_id", data.product_id);
// formData.append("add-to-cart", data.product_id);
formData.append("variation_id", variations[0].variation_id);

fetch("http://localhost:8080/wp-admin/admin-ajax.php", {
  method: "POST",
  credentials: "include",
  body: formData,
  //other options
}).then((response) =>
  response.json().then((res) => {
    console.log(res);
    Object.entries(res.fragments).forEach(([key, value]) => {
      jQuery(key, "body").replaceWith(value);
    });
  })
);
