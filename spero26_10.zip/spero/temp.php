<?php

$taxonomy     = 'product_cat';
$orderby      = 'name';
$show_count   = 1;      // 1 for yes, 0 for no
$pad_counts   = 1;      // 1 for yes, 0 for no
$hierarchical = 1;      // 1 for yes, 0 for no  
$title        = '';
$empty        = 0;

$args = array(
  'taxonomy'     => $taxonomy,
  'orderby'      => $orderby,
  'show_count'   => $show_count,
  'pad_counts'   => $pad_counts,
  'hierarchical' => $hierarchical,
  'title_li'     => $title,
  'hide_empty'   => $empty
);
$all_categories = get_categories($args);
foreach ($all_categories as $cat) {
  if ($cat->category_parent == 0 && $cat->count > 0) {
    $category_id = $cat->term_id;
    $cat_link = get_term_link($cat->slug, 'product_cat');
    $cat_name = $cat->name;
    $cat_des = $cat->description;
    echo '<br /><a href="' . get_term_link($cat->slug, 'product_cat') . '">' . $cat->name . '</a>';
    echo $cat_des;
    $results = wc_get_products(["category" => [$cat->slug]]);
    foreach ($results as $product) {
      // echo  $product->get_status();  // Product status
      // echo  $product->get_type();  // Product type
      echo  $product->get_id();    // Product ID
      echo  $product->get_title(); // Product title
      // echo  $product->get_slug(); // Product slug
      echo  $product->get_price(); // Product price
      // echo  $product->get_catalog_visibility(); // Product visibility
      // echo  $product->get_stock_status(); // Product stock status
      // product date information
      // echo $product->get_date_created()->date('Y-m-d H:i:s');
      // echo $product->get_date_modified()->date('Y-m-d H:i:s');
      echo "</br>";
    }
    // echo 'First product id is: ' . $results->products[1]->get_id() . '\n';
    // print_r($results);
  }
}
