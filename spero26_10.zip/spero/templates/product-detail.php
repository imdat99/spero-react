<?php get_header();

/*
    Template Name: Chi tiết sản phẩm
*/
?>
<h1>Chi tiết sản phẩm</h1>
<?php get_footer() ?>