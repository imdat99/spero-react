<?php get_header();

/*
    Template Name: Home
*/
?>

<div class="home__background">
  <img class="banner-img" src="wp-content/uploads/2023/10/banner.jpg" alt="banner" />
  <div class="play-icon fs-1 position-absolute top-50 start-50 translate-middle">
    <i class="fa-regular fa-circle-play fa-2xl text-light"></i>
  </div>
</div>

<main class="container spero__main">
  <section class="spero__home__content d-flex section_mt section_mb">
    <div class="story__tag spero-text-primary">
      <div class="spero_story_tag">
        <h2 class="h2 text-uppercase">Câu chuyện</h2>
        <h1 class="h1 text-uppercase fw-bold">của spero</h1>
        <a href="#" class="nav-link">Trải nghiệm thêm <i class="ms-2 fa-solid fa-arrow-right"></i></a>
      </div>
      <div class="step-line">
        <img src="wp-content/themes/spero/svg/Group-5368.svg" alt="" />
      </div>
      <div class="spero_story_tag">
        <h2 class="h2 text-uppercase">HÀNH TRÌNH 2023 - 2024</h2>
        <h1 class="h1 text-uppercase fw-bold">của ETHIOPIA</h1>
        <a href="#" class="nav-link">Trải nghiệm thêm <i class="ms-2 fa-solid fa-arrow-right"></i></a>
      </div>
      <div class="step-line">
        <img src="wp-content/themes/spero/svg/line1.svg" alt="" />
      </div>
      <div class="spero_story_tag">
        <h2 class="h2 text-uppercase">câu chuyện</h2>
        <h1 class="h1 text-uppercase fw-bold">của cà phê</h1>
        <a href="#" class="nav-link">Trải nghiệm thêm <i class="ms-2 fa-solid fa-arrow-right"></i></a>
      </div>
      <div class="step-line">
        <img src="wp-content/themes/spero/svg/line2.svg" alt="" />
      </div>
      <div class="spero_story_tag">
        <h2 class="h2 text-uppercase">Đích đến</h2>
        <h1 class="h1 text-uppercase fw-bold">thành quả</h1>
        <a href="#" class="nav-link">Trải nghiệm thêm <i class="ms-2 fa-solid fa-arrow-right"></i></a>
      </div>
    </div>
    <div class="spero__content">
      <div class="story">
        <div class="story__header">
          <span class="story_order fw-bold"> 01 </span>
          <p class="story_title fw-semibold mt-4">Câu chuyện thương hiệu</p>
          <p class="story_content spero__text">
            Spero ra đời với mong muốn mang đến cho khách hàng những trải
            nghiệm hương vị cà phê đặc sản tuyệt vời nhất. Chúng tôi coi
            việc thưởng thức cà phê đặc sản tựa như một chuyến phiêu lưu đầy
            thú vị. Được đồng hành cùng quý khách trên chuyến hành trình này
            là một vinh dự to lớn với Spero.
          </p>
          <img src="wp-content/uploads/2023/10/5f9bc49382b11b13f9566d3522c27f47.jpg" loading="lazy" alt="Câu chuyện thương hiệu" class="story_img" />
        </div>
        <div class="mini_story row">
          <div class="col">
            <div class="story__header pe-5">
              <span class="story_order fw-bold"> 02 </span>
              <p class="story_title fw-semibold mt-4">Tầm nhìn</p>
              <p class="story_content spero__text">
                Spero mang đến những hương vị mới mẻ, kết hợp tinh hoa của
                cà phê Việt Nam và thế giới. Mong muốn thổi một làn gió mới
                vào trải nghiệm thưởng thức cà phê của người Việt, chúng tôi
                nỗ lực tạo ra các sản phẩm mang tính linh hoạt cao, giúp
                khách hàng tự do khám phá những giá trị ẩn sâu trong từng
                hạt cà phê.
              </p>
            </div>
          </div>
          <div class="col">
            <div class="story__header ps-5">
              <span class="story_order fw-bold"> 03 </span>
              <p class="story_title fw-semibold mt-4">Sứ mệnh</p>
              <ul class="story_content spero__text">
                <li>
                  Đáp ứng nhu cầu thưởng thức hương vị đa giác quan Chinh
                  phục
                </li>
                <li>
                  khẩu vị cà phê người Việt bằng những hương vị chưa từng có
                  Thúc
                </li>
                <li>đẩy tinh thần tự chủ, tự do khám phá</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="section_mt section_mb">
          <h1 class="h1 fw-bold">
            "Cà phê là thức uống của những người thám hiểm."
          </h1>
          <p class="author_name">Antoine de Saint-Exupéry</p>
        </div>
      </div>
      <div class="journey">
        <img src="wp-content/themes/spero/svg/ethiopia.svg" alt="ethiopia" />
        <div class="section_mt section_mb">
          <h1 class="h1 fw-bold">
            I have measured out my life with coffee spoons.
          </h1>
          <p class="author_name au2">Thomas Stearns Eliot</p>
        </div>
      </div>
      <div class="story_coffee">
        <img src="wp-content/uploads/2023/10/d233f677ab0a1501a1d85391b71e0eab.jpg" loading="lazy" alt="Câu chuyện của cafe" class="story_img" />
        <ul class="list_story_coffee spero-text-primary">
          <li class="story_coffee_item">
            <time class="story_time">12 SEP 2023</time>
            <a href="#" class="text-decoration-none spero-text-primary">
              <h3 class="story_title fs-1 fw-semibold">
                Cupping tinh gọn với bộ giao thức Barista Hustle
              </h3>
            </a>
          </li>
          <li class="story_coffee_item">
            <time class="story_time">12 SEP 2023</time>
            <a href="#" class="text-decoration-none spero-text-primary">
              <h3 class="story_title fs-1 fw-semibold">
                Cupping tinh gọn với bộ giao thức Barista Hustle
              </h3>
            </a>
          </li>
          <li class="story_coffee_item">
            <time class="story_time">12 SEP 2023</time>
            <a href="#" class="text-decoration-none spero-text-primary">
              <h3 class="story_title fs-1 fw-semibold">
                Cupping tinh gọn với bộ giao thức Barista Hustle
              </h3>
            </a>
          </li>
        </ul>
        <div class="section_mt section_mb">
          <h1 class="h1 fw-bold">
            “The most dangerous drinking game is seeing how long I can go
            without coffee.”
          </h1>
        </div>
      </div>
      <div class="target">
        <div class="target_header mb-5">
          <h3 class="fs-1 mb-3">BST “KHÁM PHÁ"</h3>
          <p class="spero__text text-black">
            Sự kết hợp của hạt cà phê Việt Nam và Ethiopia không chỉ là bước
            đầu tiên trong cuộc hành trình khám phá hương vị cà phê đặc sản,
            mà còn là cầu nối tôn vinh những giá trị văn hóa độc đáo của cả
            hai quốc gia."
          </p>
        </div>
        <div class="spero_product_list row gx-3 gy-4">
          <?php
          $args = array(
            'limit' => 3,
            'page'  => 1,
          );
          $results = wc_get_products($args);
          // print_r($results);
          foreach ($results as $product) {
            $product_title = $product->get_title();
            $product_permalink = get_permalink($product->get_id());
            $thumbnail = get_the_post_thumbnail_url($product->get_id());
            echo '<div class="col col-md-6">
                <a href="' . $product_permalink . '" class="product_item">
                  <div class="product-img mb-5">
                    <img src="' . $thumbnail . '" />
                  </div>
                  <div class="product_name">
                    <p class="product_name_text spero-text-primary">
                      ' . $product_title . '
                    </p>
                  </div>
                </a>
              </div>';
          }
          ?>

        </div>
      </div>
    </div>
  </section>
  <section class="receive_incentives section_mb row p-5">
    <div class="col col-md-6">
      <div class="receive_percent">
        <p class="spero-text-primary text-uppercase fs-1">
          Đăng ký nhận ưu đãi
        </p>
        <h1 class="spero-text-primary">20%</h1>
        <div class="receive_percent_btn">
          <button type="button" class="btn btn-outline fw-semibold">
            Nhận ưu đãi ngay
          </button>
          <button type="button" class="btn btn-normal fw-semibold">
            Nhận ưu đãi ngay
          </button>
        </div>
      </div>
    </div>
    <div class="col col-md-6">
      <div class="coffee_bean_img">
        <img src="wp-content/uploads/2023/10/coffee_bean.jpg" alt="" />
      </div>
    </div>
  </section>
</main>
<section class="img-list mx-auto section_mb">
  <div class="img-line first-line">
    <img src="wp-content/uploads/2023/10/gallery-img.jpg" alt="1st img" />
    <img src="wp-content/uploads/2023/10/gallery-img.jpg" alt="1st img" />
    <img src="wp-content/uploads/2023/10/gallery-img.jpg" alt="1st img" />
    <img src="wp-content/uploads/2023/10/gallery-img.jpg" alt="1st img" />
  </div>
  <div class="img-line">
    <img src="wp-content/uploads/2023/10/gallery-img.jpg" alt="1st img" />
    <img src="wp-content/uploads/2023/10/gallery-img.jpg" alt="1st img" />
    <img src="wp-content/uploads/2023/10/gallery-img.jpg" alt="1st img" />
    <img src="wp-content/uploads/2023/10/gallery-img.jpg" alt="1st img" />
  </div>
</section>

<?php get_footer() ?>