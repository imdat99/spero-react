<?php get_header();

/*
    Template Name: Archive Kiến thức cà phê
*/

if (have_posts()) :
  while (have_posts()) : the_post(); ?>
    <!-- do stuff ... -->
<?php endwhile;
endif; ?>

<?php get_footer(); ?>