<?php
if (is_page("cau-chuyen-thuong-hieu")) {
  get_template_part('templates/sidebar/menu/menu', 'story', null);
} else if (is_page("lien-he")) {
  get_template_part('templates/sidebar/menu/menu', 'contact', null);
} else {
  get_template_part('templates/sidebar/menu/menu', 'default', null);
}
