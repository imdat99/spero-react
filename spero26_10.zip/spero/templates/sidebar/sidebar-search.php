<form class="search_container">
  <div class="input-group mb-3">
    <input type="text" class="form-control search-form-input" placeholder="Nhập tại đây" aria-label="search-field" aria-describedby="button-search">
    <button class="btn search-btn" type="button" id="button-search">
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
        <path d="M28.0003 28.0003L22.2096 22.2096M22.2096 22.2096C23.2001 21.2191 23.9859 20.0432 24.5219 18.749C25.058 17.4548 25.3339 16.0677 25.3339 14.6669C25.3339 13.2661 25.058 11.8791 24.5219 10.5849C23.9859 9.29071 23.2001 8.11479 22.2096 7.12428C21.2191 6.13376 20.0432 5.34804 18.749 4.81197C17.4548 4.27591 16.0677 4 14.6669 4C13.2661 4 11.8791 4.27591 10.5849 4.81197C9.29071 5.34804 8.11479 6.13376 7.12428 7.12428C5.12384 9.12472 4 11.8379 4 14.6669C4 17.496 5.12384 20.2092 7.12428 22.2096C9.12472 24.2101 11.8379 25.3339 14.6669 25.3339C17.496 25.3339 20.2092 24.2101 22.2096 22.2096Z" stroke="#717171" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
      </svg>
    </button>
  </div>
</form>