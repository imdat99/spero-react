<?php
$name = $args["name"];
$id = $args["id"];

?>
<div class="offcanvas offcanvas-end page-sidebar" tabindex="-1" id="<?php echo $id ?>" aria-labelledby="offcanvasNavbarLabel" style="overflow-y: scroll">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title spero-text-primary" id="offcanvasNavbarLabel"><?php echo $name ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" id="off-<?php echo $id ?>" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body p-0">
    <?php
    switch ($id) {
      case "search_toggle":
        get_template_part('templates/sidebar/sidebar', 'search', null);
        break;
      case "cart_toggle":
        get_template_part('templates/sidebar/sidebar', 'cart', null);
        break;
      case "menu_toggle":
        get_template_part('templates/sidebar/sidebar', 'menu', null);
        break;
      default:
        echo "none";
    }
    ?>
  </div>
</div>