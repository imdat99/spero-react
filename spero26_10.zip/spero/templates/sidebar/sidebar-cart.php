<div class="widget_shopping_cart_content">

  <?php
  // woocommerce_mini_cart();
  ?>
  <div id="spero-app-cart"></div>
</div>