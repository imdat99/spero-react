<div class="menu-container">
  <ul class="menu-list">
    <li class="menu-item">
      <a class="nav-link fw-semibold spero-text-primary " href="#tam-nhin">Tầm nhìn</a>
    </li>
    <li class="menu-item">
      <a class="nav-link fw-semibold spero-text-primary " href="#su-menh">Sứ mệnh</a>
    </li>
    <li class="menu-item">
      <a class="nav-link fw-semibold spero-text-primary " href="#gia-tri-nen-tang">Giá trị nền tảng</a>
    </li>
    <li class="menu-item">
      <a class="nav-link fw-semibold spero-text-primary " href="#cam-ket-nguon-cung-ung">Cam kết nguồn cung ứng</a>
    </li>
  </ul>
</div>