<?php get_header();

/*
    Template Name: Câu chuyện thương hiệu
*/
?>

<div class="page-container d-flex section_mb">
    <div class="story-img">
        <img src="/wp-content/uploads/2023/10/coffee-bean-story.jpg" alt="Tầm nhìn">
    </div>
    <div class="story-content d-flex flex-column">
        <div class="story-number p-0">
            <ul class="d-flex list-style-none h-50 p-0">
                <li class="story-number-item">01</li>
                <li class="story-number-item">02</li>
                <li class="story-number-item number-active story_time spero-text-secondary">03</li>
                <li class="story-number-item">04</li>
                <li class="story-number-item">05</li>
            </ul>
        </div>
        <div class="story-text h-50" id="tam-nhin">
            <h1 class="story-title text-uppercase fs-1 fw-normal spero-text-primary">Tầm nhìn</h1>
            <p class="spero__text">
                Chắt chiu tinh hoa từ những hạt cà phê đến từ cao nguyên Đà Lạt, với tinh thần tự chủ khám phá, Spero mang những tinh hoa đó rang quyện cùng các nền văn hóa cà phê trên thế giới. Mong muốn thổi một làn gió mới vào trải nghiệm thưởng thức cà phê của người Việt, Spero nỗ lực tạo ra các sản phẩm mang tính linh hoạt cao giúp khách hàng tự do khám phá những giá trị ẩn sâu trong từng hạt cà phê.
            </p>
        </div>
        <div class="story-text h-50" id="su-menh">
            <h1 class="story-title text-uppercase fs-1 fw-normal spero-text-primary">Sứ mệnh</h1>
            <ul>
                <li class="spero__text">
                    Đáp ứng nhu cầu thưởng thức hương vị đa giác quan
                </li>
                <li class="spero__text">
                    Đáp ứng nhu cầu thưởng thức hương vị đa giác quan
                </li>
                <li class="spero__text">
                    Thúc đẩy tinh thần tự chủ, tự do khám phá
                </li>
            </ul>
        </div>
        <div class="story-text h-50" id="gia-tri-nen-tang">
            <h1 class="story-title text-uppercase fs-1 fw-normal spero-text-primary">Giá trị nền tảng</h1>
            <ul>
                <li class="spero__text">
                    Tự do
                </li>
                <li class="spero__text">
                    Hào phóng
                </li>
                <li class="spero__text">
                    Khám phá
                </li>
            </ul>
        </div>
        <div class="story-text h-50" id="cam-ket-nguon-cung-ung">
            <h1 class="story-title text-uppercase fs-1 fw-normal spero-text-primary">Cam kết nguồn cung ứng</h1>
            <p class="spero__text">
                Chắt chiu tinh hoa từ những hạt cà phê đến từ cao nguyên Đà Lạt, với tinh thần tự chủ khám phá, Spero mang những tinh hoa đó rang quyện cùng các nền văn hóa cà phê trên thế giới. Mong muốn thổi một làn gió mới vào trải nghiệm thưởng thức cà phê của người Việt, Spero nỗ lực tạo ra các sản phẩm mang tính linh hoạt cao giúp khách hàng tự do khám phá những giá trị ẩn sâu trong từng hạt cà phê.
            </p>
        </div>
    </div>
</div>

<?php get_footer() ?>