<?php
$terms = get_terms(array(
  'taxonomy'   => 'kien_thuc',
  'hide_empty' => true,
));
// print_r($terms);
foreach ($terms as $term) {

?>
  <div style="display: block">
    <a href="<?php echo get_term_link($term->term_id); ?>">
      <?php echo $term->name; ?>
    </a>
    <?php
    $args = array(
      'post_type' => "kien-thuc-ca-phe",
      'tax_query' => array(
        array(
          'taxonomy' => 'kien_thuc',
          'field'    => 'term_id',
          'terms'    => $term->term_id
        )
      )
    );
    $posts = get_posts($args);
    foreach ($posts as $post) {
      // print_r($post);

      echo '<span>abc</span>';
    }
    ?>
  </div>

<?php }
?>