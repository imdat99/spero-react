<?php get_header();

/*
    Template Name: woocommerce
*/
// echo do_shortcode('[woocommerce_cart]');
global $post;
$post_slug = $post->post_name;
// echo $post_slug;

switch ($post_slug) {
    case "thanh-toan":
        echo do_shortcode('[woocommerce_checkout]');
        // echo '<noscript>'.do_shortcode('[woocommerce_checkout]').'</noscript>';
        break;
    case "gio-hang":
        // echo do_shortcode('[woocommerce_cart]');
        break;
    default:
        echo "";
}

get_footer();
