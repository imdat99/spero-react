<?php
$quantity = sprintf(_n('%d', '%d', WC()->cart->get_cart_contents_count()), WC()->cart->get_cart_contents_count());
?>
<header id="page-header" class="page-header header-color top-0 position-fixed w-100">
  <nav class="navbar">
    <div class="container">
      <a class="navbar-brand" href="/">
        <img src="/wp-content/themes/spero/svg/brand.svg" alt="" />
      </a>
      <ul class="navbar-nav">
        <li class="nav-item-button">
          <button class="navbar-toggler page-header-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#search_toggle" aria-controls="offcanvasNavbar">
            <svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g id="iconamoon:search-light">
                <path id="Vector" d="M45.5005 45.5005L36.0906 36.0906M36.0906 36.0906C37.7002 34.481 38.977 32.5702 39.8481 30.4671C40.7192 28.3641 41.1676 26.1101 41.1676 23.8338C41.1676 21.5575 40.7192 19.3035 39.8481 17.2004C38.977 15.0974 37.7002 13.1865 36.0906 11.5769C34.481 9.96736 32.5702 8.69056 30.4671 7.81946C28.3641 6.94835 26.1101 6.5 23.8338 6.5C21.5575 6.5 19.3035 6.94835 17.2004 7.81946C15.0974 8.69056 13.1865 9.96736 11.5769 11.5769C8.32623 14.8277 6.5 19.2366 6.5 23.8338C6.5 28.431 8.32623 32.8399 11.5769 36.0906C14.8277 39.3413 19.2366 41.1676 23.8338 41.1676C28.431 41.1676 32.8399 39.3413 36.0906 36.0906Z" stroke="#0F2341" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
              </g>
            </svg>

          </button>
          <button class="navbar-toggler page-header-btn  position-relative" type="button" data-bs-toggle="offcanvas" data-bs-target="#cart_toggle" aria-controls="offcanvasNavbar">
            <svg width="44" height="48" viewBox="0 0 44 48" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g id="Group">
                <path id="Vector" d="M4.10784 42.5358C6.70784 45.6667 11.5438 45.6667 21.218 45.6667H22.7823C32.4565 45.6667 37.2947 45.6667 39.8947 42.5358M4.10784 42.5358C1.50784 39.4028 2.4005 34.6492 4.18367 25.1375C5.45117 18.3775 6.08384 14.9953 8.491 12.9977M39.8947 42.5358C42.4947 39.4028 41.602 34.6492 39.8188 25.1375C38.5513 18.3775 37.9165 14.9953 35.5093 12.9977M35.5093 12.9977C33.1043 11 29.6615 11 22.7823 11H21.218C14.3388 11 10.8982 11 8.491 12.9977" stroke="#0F2341" stroke-width="3" />
                <path id="Vector_2" d="M15.5 11.0007V8.83398C15.5 7.11008 16.1848 5.45678 17.4038 4.23779C18.6228 3.0188 20.2761 2.33398 22 2.33398C23.7239 2.33398 25.3772 3.0188 26.5962 4.23779C27.8152 5.45678 28.5 7.11008 28.5 8.83398V11.0007" stroke="#0F2341" stroke-width="3" stroke-linecap="round" />
              </g>
            </svg>
            <span class="position-absolute top-50 start-50 cart-quantity" data-quantity="<?php echo  $quantity ?>" id="cart-quantity">
              <?php echo $quantity; ?>
              <span class="visually-hidden">Cart quantity</span>
            </span>

          </button>
          <button class="navbar-toggler page-header-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#menu_toggle" aria-controls="offcanvasNavbar">
            <svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g id="bytesize:menu">
                <path id="Vector" d="M6.5 13H45.5M6.5 26H45.5M6.5 39H45.5" stroke="#0F2341" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
              </g>
            </svg>

          </button>
          <?php get_template_part('templates/sidebar/sidebar', null, ["name" => "Tìm kiếm", "id" => "search_toggle"]); ?>
          <?php get_template_part('templates/sidebar/sidebar', null, ["name" => "GIỎ HÀNG", "id" => "cart_toggle"]); ?>
          <?php get_template_part('templates/sidebar/sidebar', null, ["name" => "Menu", "id" => "menu_toggle"]); ?>
        </li>
      </ul>

    </div>
  </nav>
</header>
<div class="section_mt section_mb">&nbsp;</div>