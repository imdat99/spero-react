<?php

/**
 * The template for displaying archive of Dosth Review Source taxonomy
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */
get_header();
?>
<h1>fsdafsdafsdafsa sd;fj a</h1>
<?php get_footer(); ?>