<?php

/**
 * The template for displaying 404 pages (Not Found)
 */
get_header();
?>

<div class="row justify-content-center page-container">
  <div class="col-md-12 col-sm-12">
    <div class="border-0 mt-5 mx-auto" style="width: 30rem;">
      <h3 class="display-1 text-center fw-bold">
        404
      </h3>
      <p class=" mb-2 text-center">
        Page Could Not Be Found
      </p>
      <div class="m-5"></div>
      <p class="mx-auto text-center">
        <a type="button" href="/" class="btn btn-sm btn-info text-white"> Back To Home </a>
      </p>
    </div>
  </div>
</div>

<?php get_footer() ?>