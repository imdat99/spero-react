<?php

/**
 * Archive Page template file.
 *
 * @package Spero
 */

get_header();
if (get_post_type() === 'kien-thuc-ca-phe') {
  get_template_part('templates/kien-thuc-ca-phe/archive', '', ['container_classes' => 'col-lg-4 col-md-6 col-sm-12 pb-4']);
} else {

?>
  <div id="primary">
    <main id="main" class="site-main my-5" role="main">
      <div class="container">
        <header class="page-header">
          <?php
          if (!empty(single_term_title('', false))) {
            printf(
              '<h1 class="page-title">%s</h1>',
              single_term_title('', false)
            );
          }

          if (!empty(get_the_archive_description())) {
            the_archive_description('<div class="archive-description">', '</div>');
          }
          ?>
        </header><!-- .page-header -->
        <div class="site-content">
          <div class="row">
            <?php
            if (have_posts()) :
              while (have_posts()) : the_post();
                get_template_part('templates/content', '', ['container_classes' => 'col-lg-4 col-md-6 col-sm-12 pb-4']);
              endwhile;
            else :
              echo "none";
            endif;
            ?>
          </div>
          <div>
          </div>
        </div>
      </div>
    </main>
  </div>
<?php }
get_footer();
